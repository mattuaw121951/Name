import { boolean, index, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const mackGuildSettings = pgTable("mack_guild_settings", {
  guildId: text("guild_id").primaryKey(),
  active: boolean("active").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const mackMessages = pgTable(
  "mack_messages",
  {
    id: text("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    channelId: text("channel_id").notNull(),
    authorId: text("author_id").notNull(),
    authorName: text("author_name").notNull(),
    role: text("role").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("mack_messages_channel_created_idx").on(
      table.guildId,
      table.channelId,
      table.createdAt,
    ),
    index("mack_messages_author_idx").on(table.guildId, table.authorId),
    index("mack_messages_content_search_idx").using(
      "gin",
      sql`to_tsvector('simple', ${table.content})`,
    ),
  ],
);
